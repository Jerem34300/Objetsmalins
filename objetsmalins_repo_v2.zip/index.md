---
layout: default
title: Accueil
---
# Bienvenue sur Objets Malins du Quotidien

Ici, tu trouveras chaque semaine des idées simples pour améliorer ton quotidien sans te ruiner.
**Objets astucieux, gadgets de cuisine pas chers, éclairage intelligent, accessoires pour la maison...**
Le tout à prix mini !

---

## Nos catégories
- Bons Plans
- Cuisine
- Maison
- High-Tech
- Bien-Être
